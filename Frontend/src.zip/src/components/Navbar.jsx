import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { RxHamburgerMenu } from "react-icons/rx";
import { Button, Dropdown } from "react-bootstrap";
import './Navbar.css';
import 'bootstrap/dist/css/bootstrap.min.css';

export const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    setIsLoggedIn(loggedIn);
  }, []);

  const toggleMenu = () => setMenuOpen(!menuOpen);

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('authToken');
    setIsLoggedIn(false);
    navigate('/login');
    setMenuOpen(false);
  };

  // Scroll to section function
  const scrollToSection = (sectionId) => {
    if (location.pathname === '/') {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate('/');
      setTimeout(() => {
        const section = document.getElementById(sectionId);
        if (section) {
          section.scrollIntoView({ behavior: 'smooth' });
        }
      }, 500); // Wait for navigation
    }
    setMenuOpen(false);
  };

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/members', label: 'Members' },
    { path: '/events', label: 'Events' },
    { path: '/coaching', label: 'Coaching' },
    { path: '/finances', label: 'Finances' },
    { path: '/attendance', label: 'Attendance' },
    { path: '/admission', label: 'Admission' },
    { path: 'scrollToGallery', label: 'Gallery', sectionId: 'gallery-section' },
    { path: 'scrollToContact', label: 'Contact', sectionId: 'contact-section' },
    { path: 'scrollToAbout', label: 'About Us', sectionId: 'about-section' } // Changed to use scroll functionality
  ];

  return (
    <header className="navbar-header fs-2" style={{
      background: 'rgba(255, 255, 255, 0.85)',
      backdropFilter: 'blur(10px)',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      borderBottom: '1px solid rgba(0,0,0,0.08)'
    }}>
      <div className="container">
        <div className="d-flex justify-content-between align-items-center py-3">
          <div className="d-flex align-items-center">
            <div className="me-3">
              <img 
                src="/src/assets/Picture2.png" 
                alt="logo" 
                style={{ height: '60px', cursor: 'pointer', transition: 'transform 0.3s ease' }}
                onClick={() => navigate('/')}
                onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
              />
            </div>
            <h1 className="mb-0 fs-4 fw-bold" style={{ color: '#2c3e50', textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
              Bijoy Institute
            </h1>
          </div>

          <nav className="d-none d-md-flex align-items-center">
            <ul className="nav mb-0">
              {navItems.map(({ path, label, sectionId }) => (
                <li className="nav-item mx-2" key={label}>
                  {path.startsWith('scrollTo') ? (
                    <button
                      onClick={() => scrollToSection(sectionId)}
                      className="nav-link px-3 py-2 rounded text-dark fw-medium bg-transparent border-0"
                      style={{ fontSize: '1.05rem', cursor: 'pointer' }}
                    >
                      {label}
                    </button>
                  ) : (
                    <NavLink 
                      to={path}
                      className={({ isActive }) =>
                        `nav-link px-3 py-2 rounded ${isActive ? 'bg-primary text-white' : 'text-dark fw-medium'}`
                      }
                      style={{ fontSize: '1.05rem' }}
                    >
                      {label}
                    </NavLink>
                  )}
                </li>
              ))}
            </ul>

            <div className="ms-4">
              {isLoggedIn ? (
                <Dropdown align="end">
                  <Dropdown.Toggle 
                    variant="outline-primary"
                    className="fs-6 px-4 py-2 fw-bold"
                    style={{ borderRadius: '8px' }}
                  >
                    <i className="bi bi-person-circle me-2"></i> Account
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="shadow-sm border-0">
                    <Dropdown.Item onClick={() => navigate('/profile')} className="fs-6 py-2">
                      <i className="bi bi-person me-2"></i> Profile
                    </Dropdown.Item>
                    <Dropdown.Item onClick={handleLogout} className="fs-6 py-2 text-danger">
                      <i className="bi bi-box-arrow-right me-2"></i> Logout
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              ) : (
                <Button 
                  variant="primary"
                  onClick={() => navigate('/login')}
                  className="px-4 py-2 fs-6 fw-bold"
                  style={{ borderRadius: '8px' }}
                >
                  <i className="bi bi-box-arrow-in-right me-2"></i> Login
                </Button>
              )}
            </div>
          </nav>

          <div className="d-md-none">
            <button 
              onClick={toggleMenu} 
              className="btn btn-outline-secondary p-2"
              style={{ borderRadius: '8px', width: '44px', height: '44px' }}
              aria-label="Toggle Menu"
            >
              <RxHamburgerMenu size={24} />
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="d-md-none mt-3 p-4 bg-white rounded shadow-sm" style={{ animation: 'fadeIn 0.3s ease-out' }}>
            <ul className="nav flex-column gap-2">
              {navItems.map(({ path, label, sectionId }) => (
                <li className="nav-item" key={label}>
                  {path.startsWith('scrollTo') ? (
                    <button
                      onClick={() => scrollToSection(sectionId)}
                      className="nav-link px-3 py-2 rounded text-start text-dark fw-medium bg-transparent border-0"
                      style={{ fontSize: '1.05rem' }}
                    >
                      {label}
                    </button>
                  ) : (
                    <NavLink 
                      to={path}
                      className={({ isActive }) =>
                        `nav-link px-3 py-2 rounded fw-medium ${isActive ? 'bg-primary text-white' : 'text-dark'}`
                      }
                      style={{ fontSize: '1.05rem' }}
                      onClick={() => setMenuOpen(false)}
                    >
                      {label}
                    </NavLink>
                  )}
                </li>
              ))}
            </ul>

            <div className="d-grid gap-3 mt-4">
              {isLoggedIn ? (
                <>
                  <Button 
                    variant="outline-primary"
                    onClick={() => { navigate('/profile'); setMenuOpen(false); }}
                    className="py-2 fs-6"
                  >
                    <i className="bi bi-person me-2"></i> Profile
                  </Button>
                  <Button 
                    variant="danger"
                    onClick={handleLogout}
                    className="py-2 fs-6"
                  >
                    <i className="bi bi-box-arrow-right me-2"></i> Logout
                  </Button>
                </>
              ) : (
                <Button 
                  variant="primary"
                  onClick={() => { navigate('/login'); setMenuOpen(false); }}
                  className="py-2 fs-6"
                >
                  <i className="bi bi-box-arrow-in-right me-2"></i> Login
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .nav-link:hover {
          background-color: rgba(0,0,0,0.03);
        }
      `}</style>
    </header>
  );
};