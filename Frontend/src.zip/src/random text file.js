react-image-gallery
// Sample images - replace with your actual images
  const images = [
    { src: 'src/assets/images/gallery1.jpg', alt: 'Training session' },
    { src: 'src/assets/images/gallery2.jpg', alt: 'Championship match' },
    { src: 'src/assets/images/gallery3.jpg', alt: 'Coaching workshop' },
    { src: 'src/assets/images/gallery4.jpg', alt: 'Award ceremony' },
    { src: 'src/assets/images/gallery5.jpg', alt: 'Team practice' },
    { src: 'src/assets/images/gallery6.jpg', alt: 'Tournament action' },
    { src: 'src/assets/images/gallery7.jpg', alt: 'Junior players' },
    { src: 'src/assets/images/gallery8.jpg', alt: 'Facility tour' },
    { src: 'src/assets/images/gallery9.jpg', alt: 'Guest coach' },
    { src: 'src/assets/images/gallery10.jpg', alt: 'Alumni meet' },
    { src: 'src/assets/images/gallery11.jpg', alt: 'Summer camp' },
    { src: 'src/assets/images/gallery12.jpg', alt: 'Equipment showcase' },
  ];